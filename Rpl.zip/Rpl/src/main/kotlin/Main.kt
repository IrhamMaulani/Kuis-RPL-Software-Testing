
fun main(args: Array<String>) {
    val obj = Student("Budi", 5, "10101999","6208235837686")
    obj.Detail()
    obj.Hobi()
    val obj1 = Ortu("Jurnadi", "Jurniti")
    obj1.Detail1()
}