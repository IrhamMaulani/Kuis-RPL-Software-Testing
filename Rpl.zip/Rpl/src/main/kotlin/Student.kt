

class Student(var nama: String, id : Int, var tanggal: String, var nomor: String) {
    var iD = id
    var hobi = arrayOf<String>("Bersepeda", "Makan", "Bernyanyi")
    val pertama = nama.first()
    fun Detail(){
        val detail =""" Nama: $nama
                        Id: $iD
                        Tanggal Lahir: $tanggal
                        Nomor: $nomor
                        NIM: $iD$pertama$tanggal
                        """
        print(detail)
    }

    fun Hobi(): Array<String> {
        return hobi
    }


}
class Ortu(var ayah : String, var ibu: String) {
    var nAyah = ayah
    var nIbu = ibu

    fun Detail1(){
        val detail1 ="""Nama: $nAyah
                        Nama: $nIbu"""

        print(detail1)
    }
}
