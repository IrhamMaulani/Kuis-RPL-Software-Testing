
rootProject.name = "Rpl"

